function Dashboard() {
  try {
    return (
      <section className="py-20 px-4" data-name="dashboard" data-file="components/Dashboard.js">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Intuitive Dashboard<br /><span className="gradient-text">At Your Fingertips</span></h2>
            <p className="text-[var(--text-secondary)] text-lg max-w-2xl mx-auto">Real-time insights into your SACCO's performance.</p>
          </div>
          <div className="glass-card rounded-3xl p-2 glow-orange dashboard-3d">
            <div className="bg-[var(--bg-secondary)] rounded-2xl p-6 preserve-3d">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Total Deposits', value: 'KES 847.2M', change: '+12.5%', up: true },
                  { label: 'Active Loans', value: 'KES 623.8M', change: '+8.3%', up: true },
                  { label: 'Members', value: '50,234', change: '+156', up: true },
                  { label: 'Repayment Rate', value: '98.2%', change: '+0.5%', up: true }
                ].map((m, i) => (
                  <div key={i} className="glass-card rounded-xl p-4">
                    <div className="text-sm text-[var(--text-secondary)] mb-1">{m.label}</div>
                    <div className="text-xl font-bold text-white">{m.value}</div>
                    <div className={`text-xs ${m.up ? 'text-[var(--secondary-color)]' : 'text-red-400'}`}>{m.change}</div>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 glass-card rounded-xl p-4 h-48">
                  <div className="text-sm font-semibold mb-2">Savings & Loans Analytics</div>
                  <div className="flex items-end justify-around h-32 gap-2">
                    {[60, 80, 45, 90, 70, 85, 55, 95, 75, 88, 65, 92].map((h, i) => (
                      <div key={i} className="flex flex-col items-center gap-1 flex-1">
                        <div className="w-full bg-[var(--primary-color)] rounded-t" style={{ height: `${h}%`, opacity: 0.8 }}></div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="glass-card rounded-xl p-4 h-48">
                  <div className="text-sm font-semibold mb-2">Recent Transactions</div>
                  <div className="space-y-2">
                    {['M-Pesa Deposit', 'Loan Disbursement', 'Savings Withdrawal', 'Loan Repayment'].map((t, i) => (
                      <div key={i} className="flex items-center justify-between text-xs">
                        <span className="text-[var(--text-secondary)]">{t}</span>
                        <span className="text-white">KES {(Math.random() * 50000).toFixed(0)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  } catch (error) { console.error('Dashboard error:', error); return null; }
}